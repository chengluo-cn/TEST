--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.12
-- Dumped by pg_dump version 14.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE discovery;
--
-- Name: discovery; Type: DATABASE; Schema: -; Owner: discovery
--

CREATE DATABASE discovery WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.utf8';


ALTER DATABASE discovery OWNER TO discovery;

\connect discovery

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address_space; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.address_space (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    job_name character varying(32),
    job_type character varying(32),
    label character varying(32),
    scan_date character varying(32),
    step_name character varying(32)
);


ALTER TABLE public.address_space OWNER TO rgroup;

--
-- Name: bind_address; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.bind_address (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    path character varying(32),
    port_number integer,
    scan_date character varying(32)
);


ALTER TABLE public.bind_address OWNER TO rgroup;

--
-- Name: cics_db2_conn; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.cics_db2_conn (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    scan_date character varying(32)
);


ALTER TABLE public.cics_db2_conn OWNER TO rgroup;

--
-- Name: cics_file; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.cics_file (
    dla_id character varying(64) NOT NULL,
    add boolean,
    browse boolean,
    data_source character varying(8),
    dataset_name character varying(128),
    file_delete boolean,
    file_group character varying(8),
    file_name character varying(128),
    file_read boolean,
    file_update timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    key_length character varying(8),
    label character varying(64),
    open_time character varying(8),
    record_size character varying(8),
    scan_date character varying(32),
    status character varying(255)
);


ALTER TABLE public.cics_file OWNER TO rgroup;

--
-- Name: cics_plex; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.cics_plex (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    mvs_sys_id character varying(8),
    name character varying(16),
    scan_date character varying(32)
);


ALTER TABLE public.cics_plex OWNER TO rgroup;

--
-- Name: cics_program; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.cics_program (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    label character varying(64),
    prog_data_location character varying(255),
    prog_desc character varying(64),
    prog_exec_key character varying(255),
    prog_group character varying(8),
    prog_language character varying(255),
    prog_name character varying(32),
    scan_date character varying(32)
);


ALTER TABLE public.cics_program OWNER TO rgroup;

--
-- Name: cics_region; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.cics_region (
    dla_id character varying(64) NOT NULL,
    appl_id character varying(8),
    cics_version character varying(8),
    data_source character varying(8),
    dfh_cics_hlq character varying(16),
    dfh_cics_type character varying(8),
    dfh_le_hlq character varying(16),
    dfh_region_cicssvc character varying(8),
    dfh_region_dfltuser character varying(8),
    dfh_region_hlq character varying(16),
    dfh_region_logstream character varying(32),
    job_name character varying(8),
    label character varying(32),
    net_id character varying(8),
    region_name character varying(32),
    scan_date character varying(32)
);


ALTER TABLE public.cics_region OWNER TO rgroup;

--
-- Name: cics_sit; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.cics_sit (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    name character varying(32),
    scan_date character varying(32),
    sit_applid character varying(32),
    sit_cics_svc character varying(8),
    sit_cps_conn character varying(8),
    sit_csd_acc character varying(16),
    sit_csd_rls character varying(8),
    sit_dftl_user character varying(16),
    sit_gmtext character varying(128),
    sit_gm_tran character varying(8),
    sit_irc_strt character varying(8),
    sit_isc character varying(8),
    sit_jvm_profile_dir character varying(64)
);


ALTER TABLE public.cics_sit OWNER TO rgroup;

--
-- Name: cics_sit_overrides; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.cics_sit_overrides (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    name character varying(32),
    scan_date character varying(32),
    sit_applid character varying(32),
    sit_cics_svc character varying(8),
    sit_cps_conn character varying(8),
    sit_csd_acc character varying(16),
    sit_csd_rls character varying(8),
    sit_dftl_user character varying(16),
    sit_gmtext character varying(128),
    sit_gm_tran character varying(8),
    sit_irc_strt character varying(8),
    sit_isc character varying(8),
    sit_jvm_profile_dir character varying(64)
);


ALTER TABLE public.cics_sit_overrides OWNER TO rgroup;

--
-- Name: cics_transaction; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.cics_transaction (
    dla_id character varying(64) NOT NULL,
    data_key character varying(8),
    data_location character varying(128),
    data_source character varying(8),
    initial_program character varying(32),
    label character varying(64),
    scan_date character varying(32),
    trans_name character varying(4)
);


ALTER TABLE public.cics_transaction OWNER TO rgroup;

--
-- Name: db2_buffer_pool; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.db2_buffer_pool (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    label character varying(64),
    name character varying(8),
    num_pages integer,
    page_size integer,
    pool_id integer,
    scan_date character varying(32)
);


ALTER TABLE public.db2_buffer_pool OWNER TO rgroup;

--
-- Name: db2_data_sharing_group; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.db2_data_sharing_group (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    group_attach_name character varying(8),
    group_function character varying(32),
    label character varying(32),
    name character varying(16),
    scan_date character varying(32),
    sys_columns_max_altered_ts timestamp(6) without time zone,
    sys_database_xax_altered_ts timestamp(6) without time zone,
    sys_indexes_max_altered_ts timestamp(6) without time zone,
    sys_table_max_altered_ts timestamp(6) without time zone,
    sys_table_space_max_altered_ts timestamp(6) without time zone
);


ALTER TABLE public.db2_data_sharing_group OWNER TO rgroup;

--
-- Name: db2_database; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.db2_database (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    label character varying(32),
    name character varying(16),
    scan_date character varying(32)
);


ALTER TABLE public.db2_database OWNER TO rgroup;

--
-- Name: db2_stored_procedure; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.db2_stored_procedure (
    dla_id character varying(128) NOT NULL,
    coll_id character varying(128),
    data_source character varying(8),
    external_name character varying(128),
    label character varying(128),
    language character varying(128),
    name character varying(128),
    origin character varying(128),
    routine_type character varying(128),
    scan_date character varying(32),
    specific_name character varying(128)
);


ALTER TABLE public.db2_stored_procedure OWNER TO rgroup;

--
-- Name: db2_subsystem; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.db2_subsystem (
    dla_id character varying(64) NOT NULL,
    ddf_location character varying(32),
    command_prefix_name character varying(16),
    controlling_address_space character varying(16),
    data_source character varying(8),
    key_name character varying(16),
    label character varying(16),
    major_version integer,
    modifier integer,
    release integer,
    scan_date character varying(32),
    subsystem_name character varying(8)
);


ALTER TABLE public.db2_subsystem OWNER TO rgroup;

--
-- Name: db2_table; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.db2_table (
    dla_id character varying(64) NOT NULL,
    data_base character varying(16),
    data_source character varying(8),
    label character varying(64),
    name character varying(16),
    scan_date character varying(32),
    sharing_group character varying(16),
    table_space character varying(16)
);


ALTER TABLE public.db2_table OWNER TO rgroup;

--
-- Name: db2_table_space; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.db2_table_space (
    dla_id character varying(64) NOT NULL,
    comments character varying(16),
    content_type character varying(8),
    data_source character varying(8),
    label character varying(64),
    name character varying(16),
    page_size integer,
    scan_date character varying(32),
    size bigint,
    space_id integer,
    type character varying(8)
);


ALTER TABLE public.db2_table_space OWNER TO rgroup;

--
-- Name: fqdn; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.fqdn (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    fqdn character varying(32),
    scan_date character varying(32)
);


ALTER TABLE public.fqdn OWNER TO rgroup;

--
-- Name: idml_operation_time; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.idml_operation_time (
    host_label character varying(32) NOT NULL,
    create_timestamp character varying(32),
    data_source character varying(8),
    delete_timestamp character varying(32),
    modify_timestamp character varying(32),
    refresh_timestamp character varying(32)
);


ALTER TABLE public.idml_operation_time OWNER TO rgroup;

--
-- Name: ims_database; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.ims_database (
    dla_id character varying(64) NOT NULL,
    imsdatabasetype character varying(64),
    data_source character varying(8),
    label character varying(64),
    name character varying(64),
    scan_date character varying(32)
);


ALTER TABLE public.ims_database OWNER TO rgroup;

--
-- Name: ims_program; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.ims_program (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    label character varying(64),
    name character varying(64),
    scan_date character varying(32)
);


ALTER TABLE public.ims_program OWNER TO rgroup;

--
-- Name: ims_subsystem; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.ims_subsystem (
    dla_id character varying(64) NOT NULL,
    cqsgroupname character varying(64),
    imsplexgroupname character varying(64),
    imssubsystype character varying(64),
    irlmgroupname character varying(64),
    commandprefixname character varying(64),
    controllingaddressspace character varying(64),
    data_source character varying(8),
    databaseschecksum character varying(64),
    keyname character varying(64),
    label character varying(64),
    programschecksum character varying(64),
    scan_date character varying(32),
    subsystemname character varying(64),
    transactionschecksum character varying(64),
    versionstring character varying(64)
);


ALTER TABLE public.ims_subsystem OWNER TO rgroup;

--
-- Name: ims_transaction; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.ims_transaction (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    label character varying(64),
    name character varying(64),
    scan_date character varying(32)
);


ALTER TABLE public.ims_transaction OWNER TO rgroup;

--
-- Name: ip_address; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.ip_address (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    label character varying(32),
    scan_date character varying(32),
    string_notation character varying(32)
);


ALTER TABLE public.ip_address OWNER TO rgroup;

--
-- Name: ip_interface; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.ip_interface (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    scan_date character varying(32)
);


ALTER TABLE public.ip_interface OWNER TO rgroup;

--
-- Name: jcl_dynamic_data; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.jcl_dynamic_data (
    jcl_id character varying(64) NOT NULL,
    dataset_name character varying(64),
    deleted boolean,
    executing_sysplex_name character varying(64),
    executing_zos_name character varying(64),
    extra character varying(1024),
    job_name character varying(64),
    member_name character varying(64),
    parent_job_name character varying(64),
    parent_lpar_name character varying(64),
    run_on_lpar_name character varying(64),
    sysplex_name character varying(64),
    "timestamp" character varying(64),
    type character varying(64),
    unique_id character varying(64),
    version character varying(64),
    zos_name character varying(64)
);


ALTER TABLE public.jcl_dynamic_data OWNER TO rgroup;

--
-- Name: jcl_file_data; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.jcl_file_data (
    jcl_id character varying(64) NOT NULL,
    dataset_name character varying(64),
    deleted boolean,
    extra character varying(1024),
    job_descriptor_id character varying(64),
    member_name character varying(64),
    sysplex_name character varying(64),
    "timestamp" character varying(64),
    type character varying(64),
    unique_id character varying(64),
    version character varying(64)
);


ALTER TABLE public.jcl_file_data OWNER TO rgroup;

--
-- Name: jcl_operation_data; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.jcl_operation_data (
    jcl_id character varying(64) NOT NULL,
    dataset_name character varying(64),
    deleted boolean,
    executing_sysplex_name character varying(64),
    executing_zos_name character varying(64),
    extra character varying(10240),
    job_name character varying(64),
    job_descriptor_id character varying(64),
    lpar_name character varying(64),
    member_name character varying(64),
    parent_job_name character varying(64),
    parent_lpar_name character varying(64),
    route_card character varying(64),
    sysplex_name character varying(64),
    "timestamp" character varying(64),
    type character varying(64),
    unique_id character varying(64),
    version character varying(64),
    zos_name character varying(64)
);


ALTER TABLE public.jcl_operation_data OWNER TO rgroup;

--
-- Name: jcl_route_card; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.jcl_route_card (
    route_card_id character varying(64) NOT NULL,
    deleted boolean,
    extra character varying(512),
    route_card character varying(64),
    "timestamp" character varying(64),
    type character varying(64),
    unique_id character varying(64),
    version character varying(64)
);


ALTER TABLE public.jcl_route_card OWNER TO rgroup;

--
-- Name: jcl_static_data; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.jcl_static_data (
    jcl_id character varying(64) NOT NULL,
    dataset_name character varying(64),
    deleted boolean,
    executing_sysplex_name character varying(64),
    executing_zos_name character varying(64),
    extra character varying(10240),
    job_name character varying(64),
    job_descriptor_id character varying(64),
    lpar_name character varying(64),
    member_name character varying(64),
    parent_job_name character varying(64),
    parent_lpar_name character varying(64),
    route_card character varying(64),
    sysplex_name character varying(64),
    "timestamp" character varying(64),
    type character varying(64),
    unique_id character varying(64),
    version character varying(64),
    zos_name character varying(64)
);


ALTER TABLE public.jcl_static_data OWNER TO rgroup;

--
-- Name: jcl_system_relationship; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.jcl_system_relationship (
    sysplex character varying(64) NOT NULL,
    deleted boolean,
    lpar character varying(128),
    "timestamp" character varying(64),
    type character varying(64),
    version character varying(64)
);


ALTER TABLE public.jcl_system_relationship OWNER TO rgroup;

--
-- Name: lpar; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.lpar (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    label character varying(64),
    lpar_name character varying(16),
    memory_size bigint,
    model character varying(8),
    model_id character varying(8),
    name character varying(64),
    num_cpus integer,
    num_dedicated_cps integer,
    num_shared_cps integer,
    scan_date character varying(32),
    vm_id character varying(4)
);


ALTER TABLE public.lpar OWNER TO rgroup;

--
-- Name: module_definition; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.module_definition (
    dla_id character varying(64) NOT NULL,
    language character varying(8),
    name character varying(16),
    scan_date character varying(32),
    sourcefile character varying(256),
    type character varying(8)
);


ALTER TABLE public.module_definition OWNER TO rgroup;

--
-- Name: mq_alias_queue; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.mq_alias_queue (
    dla_id character varying(80) NOT NULL,
    data_source character varying(8),
    default_persistence character varying(64),
    description character varying(255),
    get boolean,
    label character varying(64),
    name character varying(64),
    put boolean,
    qsdgisp character varying(255),
    scan_date character varying(32),
    target_queue character varying(64)
);


ALTER TABLE public.mq_alias_queue OWNER TO rgroup;

--
-- Name: mq_auth_info; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.mq_auth_info (
    dla_id character varying(80) NOT NULL,
    data_source character varying(8),
    label character varying(64),
    ldap_server_name character varying(64),
    name character varying(64),
    queue_manager character varying(64),
    scan_date character varying(32),
    type character varying(64),
    user_name character varying(64)
);


ALTER TABLE public.mq_auth_info OWNER TO rgroup;

--
-- Name: mq_buffer_pool; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.mq_buffer_pool (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    id_sequence character varying(8),
    label character varying(64),
    number integer,
    scan_date character varying(32)
);


ALTER TABLE public.mq_buffer_pool OWNER TO rgroup;

--
-- Name: mq_client_connection_channel; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.mq_client_connection_channel (
    dla_id character varying(80) NOT NULL,
    data_source character varying(8),
    headercompression character varying(64),
    heartbeatinterval integer,
    keepaliveinterval integer,
    label character varying(64),
    maxmessagelength integer,
    messagecompression character varying(64),
    name character varying(64),
    queuesharinggroupdisposition character varying(64),
    scan_date character varying(32)
);


ALTER TABLE public.mq_client_connection_channel OWNER TO rgroup;

--
-- Name: mq_cluster_receiver_channel; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.mq_cluster_receiver_channel (
    dla_id character varying(80) NOT NULL,
    batchheartbeatinterval integer,
    batchinterval integer,
    batchsize integer,
    clwlchannelpriority character varying(64),
    clwlchannelrank character varying(64),
    clwlchannelweight character varying(64),
    connectionname character varying(64),
    dataconversion boolean,
    data_source character varying(8),
    disconnectinterval integer,
    headercompression character varying(64),
    heartbeatinterval integer,
    keepaliveinterval integer,
    label character varying(64),
    longretrycount integer,
    longretrytimer integer,
    maxmessagelength integer,
    mcatype character varying(64),
    messagecompression character varying(64),
    messageretrycount integer,
    messageretryinterval integer,
    name character varying(64),
    nonpersistentmessagespeed character varying(64),
    putauthority character varying(64),
    queuesharinggroupdisposition character varying(64),
    scan_date character varying(32),
    shortretrycount integer,
    shortretrytimer integer,
    sslclientauthentication boolean
);


ALTER TABLE public.mq_cluster_receiver_channel OWNER TO rgroup;

--
-- Name: mq_cluster_sender_channel; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.mq_cluster_sender_channel (
    dla_id character varying(80) NOT NULL,
    batchheartbeatinterval integer,
    batchinterval integer,
    batchsize integer,
    clwlchannelpriority character varying(64),
    clwlchannelrank character varying(64),
    clwlchannelweight character varying(64),
    connectionname character varying(64),
    dataconversion boolean,
    data_source character varying(8),
    disconnectinterval integer,
    headercompression character varying(64),
    heartbeatinterval integer,
    keepaliveinterval integer,
    label character varying(64),
    longretrycount integer,
    longretrytimer integer,
    maxmessagelength integer,
    messagecompression character varying(64),
    name character varying(64),
    nonpersistentmessagespeed character varying(64),
    queuesharinggroupdisposition character varying(64),
    scan_date character varying(32),
    shortretrycount integer,
    shortretrytimer integer
);


ALTER TABLE public.mq_cluster_sender_channel OWNER TO rgroup;

--
-- Name: mq_listener; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.mq_listener (
    dla_id character varying(80) NOT NULL,
    control character varying(64),
    data_source character varying(8),
    label character varying(64),
    name character varying(64),
    queuemanager character varying(255),
    remotename character varying(64),
    scan_date character varying(32),
    starttime timestamp(6) without time zone
);


ALTER TABLE public.mq_listener OWNER TO rgroup;

--
-- Name: mq_local_queue; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.mq_local_queue (
    dla_id character varying(80) NOT NULL,
    data_source character varying(8),
    defaultpersistence character varying(64),
    definitiontype character varying(64),
    get boolean,
    label character varying(64),
    maxmessagelength integer,
    maxqueuedepth integer,
    name character varying(64),
    put boolean,
    qsgdisp character varying(64),
    scan_date character varying(32),
    transmissionusage character varying(64),
    triggercontrol boolean,
    triggerdata character varying(64),
    triggerdepth integer,
    triggertype character varying(64)
);


ALTER TABLE public.mq_local_queue OWNER TO rgroup;

--
-- Name: mq_model_queue; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.mq_model_queue (
    dla_id character varying(80) NOT NULL,
    data_source character varying(8),
    defaultpersistence character varying(64),
    definitiontype character varying(64),
    description character varying(255),
    get boolean,
    initiationqueue character varying(64),
    label character varying(64),
    name character varying(64),
    put boolean,
    qsgdisp character varying(64),
    scan_date character varying(32),
    transmissionusage character varying(64),
    triggercontrol boolean,
    triggerdata character varying(64),
    triggerdepth integer,
    triggertype character varying(64)
);


ALTER TABLE public.mq_model_queue OWNER TO rgroup;

--
-- Name: mq_receiver_channel; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.mq_receiver_channel (
    dla_id character varying(80) NOT NULL,
    batchsize integer,
    data_source character varying(8),
    headercompression character varying(64),
    heartbeatinterval integer,
    keepaliveinterval integer,
    label character varying(64),
    maxmessagelength integer,
    messagecompression character varying(64),
    messageretrycount integer,
    messageretryinterval integer,
    name character varying(64),
    nonpersistentmessagespeed character varying(64),
    putauthority character varying(64),
    queuesharinggroupdisposition character varying(64),
    scan_date character varying(32),
    sslcipherspecification character varying(64),
    sslclientauthentication boolean
);


ALTER TABLE public.mq_receiver_channel OWNER TO rgroup;

--
-- Name: mq_remote_queue; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.mq_remote_queue (
    dla_id character varying(80) NOT NULL,
    data_source character varying(8),
    defaultpersistence character varying(64),
    label character varying(64),
    name character varying(64),
    put boolean,
    qsgdisp character varying(64),
    remotename character varying(64),
    remotequeuemgrname character varying(64),
    scan_date character varying(32)
);


ALTER TABLE public.mq_remote_queue OWNER TO rgroup;

--
-- Name: mq_sender_channel; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.mq_sender_channel (
    dla_id character varying(80) NOT NULL,
    batchheartbeatinterval integer,
    batchinterval integer,
    batchsize integer,
    connectionname character varying(64),
    dataconversion boolean,
    data_source character varying(8),
    disconnectinterval integer,
    headercompression character varying(64),
    heartbeatinterval integer,
    keepaliveinterval integer,
    label character varying(64),
    longretrycount integer,
    longretrytimer integer,
    maxmessagelength integer,
    messagecompression character varying(64),
    name character varying(64),
    nonpersistentmessagespeed character varying(64),
    queuesharinggroupdisposition character varying(64),
    scan_date character varying(32),
    shortretrycount integer,
    shortretrytimer integer,
    transmissionqueue character varying(64)
);


ALTER TABLE public.mq_sender_channel OWNER TO rgroup;

--
-- Name: mq_server_connection_channel; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.mq_server_connection_channel (
    dla_id character varying(80) NOT NULL,
    data_source character varying(8),
    description character varying(255),
    disconnectinterval integer,
    headercompression character varying(64),
    heartbeatinterval integer,
    keepaliveinterval integer,
    label character varying(64),
    maxmessagelength integer,
    messagecompression character varying(64),
    name character varying(64),
    queuesharinggroupdisposition character varying(64),
    scan_date character varying(32),
    sslclientauthentication boolean
);


ALTER TABLE public.mq_server_connection_channel OWNER TO rgroup;

--
-- Name: mq_subsystem; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.mq_subsystem (
    dla_id character varying(64) NOT NULL,
    commandprefixname character varying(64),
    controllingaddressspace character varying(64),
    data_source character varying(8),
    label character varying(64),
    scan_date character varying(32),
    subsystemname character varying(64),
    versionstring character varying(64)
);


ALTER TABLE public.mq_subsystem OWNER TO rgroup;

--
-- Name: process_pool; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.process_pool (
    dla_id character varying(64) NOT NULL,
    cmd_line character varying(256),
    data_source character varying(8),
    label character varying(32),
    name character varying(32),
    scan_date character varying(32)
);


ALTER TABLE public.process_pool OWNER TO rgroup;

--
-- Name: program_definition; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.program_definition (
    dla_id character varying(64) NOT NULL,
    language character varying(8),
    loc character varying(8),
    locmt character varying(8),
    name character varying(16),
    rloc character varying(8),
    scan_date character varying(32),
    type character varying(8)
);


ALTER TABLE public.program_definition OWNER TO rgroup;

--
-- Name: relationship; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.relationship (
    name character varying(32) NOT NULL,
    source character varying(80) NOT NULL,
    target character varying(80) NOT NULL,
    data_source character varying(8),
    reverse_name character varying(32)
);


ALTER TABLE public.relationship OWNER TO rgroup;

--
-- Name: relationship_service_now; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.relationship_service_now (
    name character varying(32) NOT NULL,
    source character varying(80) NOT NULL,
    target character varying(80) NOT NULL,
    data_source character varying(8),
    reverse_name character varying(32),
    source_type character varying(32),
    target_type character varying(32)
);


ALTER TABLE public.relationship_service_now OWNER TO rgroup;

--
-- Name: sysplex; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.sysplex (
    dla_id character varying(64) NOT NULL,
    grs_config bytea,
    data_source character varying(8),
    label character varying(32),
    maxsys integer,
    name character varying(32),
    plex_mode bytea,
    scan_date character varying(32)
);


ALTER TABLE public.sysplex OWNER TO rgroup;

--
-- Name: table_definition; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.table_definition (
    dla_id character varying(64) NOT NULL,
    name character varying(16),
    scan_date character varying(32),
    type character varying(8)
);


ALTER TABLE public.table_definition OWNER TO rgroup;

--
-- Name: tcp_port; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.tcp_port (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    label character varying(32),
    port_number integer,
    scan_date character varying(32)
);


ALTER TABLE public.tcp_port OWNER TO rgroup;

--
-- Name: trancode_definition; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.trancode_definition (
    dla_id character varying(64) NOT NULL,
    name character varying(16),
    scan_date character varying(32),
    type character varying(8)
);


ALTER TABLE public.trancode_definition OWNER TO rgroup;

--
-- Name: udp_port; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.udp_port (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    label character varying(32),
    port_number integer,
    scan_date character varying(32)
);


ALTER TABLE public.udp_port OWNER TO rgroup;

--
-- Name: z_series_computer; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.z_series_computer (
    dla_id character varying(64) NOT NULL,
    cpu_speed bigint,
    data_source character varying(8),
    label character varying(64),
    make character varying(4) NOT NULL,
    manufacturer character varying(8),
    memory_size bigint,
    model character varying(8) NOT NULL,
    model_id character varying(8),
    name character varying(16),
    num_cpus integer,
    process_capacity_units character varying(8),
    processing_capacity character varying(32),
    scan_date character varying(32),
    serial_number character varying(16) NOT NULL
);


ALTER TABLE public.z_series_computer OWNER TO rgroup;

--
-- Name: z_subsystem; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.z_subsystem (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    label character varying(64),
    scan_date character varying(32),
    subsystem_manufacturer character varying(8),
    subsystem_name character varying(32),
    subsystem_version character varying(8),
    type character varying(4)
);


ALTER TABLE public.z_subsystem OWNER TO rgroup;

--
-- Name: zos; Type: TABLE; Schema: public; Owner: rgroup
--

CREATE TABLE public.zos (
    dla_id character varying(64) NOT NULL,
    data_source character varying(8),
    fqdn character varying(32),
    ipl_parm_dataset character varying(16),
    ipl_parm_device character varying(8),
    ipl_parm_member character varying(16),
    ipl_parm_volume character varying(8),
    label character varying(64),
    name character varying(16),
    net_id character varying(8),
    os_freindly_name character varying(32),
    os_name character varying(16),
    os_rsu_level character varying(8),
    os_version character varying(8),
    scan_date character varying(32),
    smf_id character varying(8),
    sscp character varying(16),
    sys_res_volume character varying(8)
);


ALTER TABLE public.zos OWNER TO rgroup;

--
-- Data for Name: address_space; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.address_space (dla_id, data_source, job_name, job_type, label, scan_date, step_name) FROM stdin;
\.
COPY public.address_space (dla_id, data_source, job_name, job_type, label, scan_date, step_name) FROM '$$PATH$$/3317.dat';

--
-- Data for Name: bind_address; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.bind_address (dla_id, data_source, path, port_number, scan_date) FROM stdin;
\.
COPY public.bind_address (dla_id, data_source, path, port_number, scan_date) FROM '$$PATH$$/3318.dat';

--
-- Data for Name: cics_db2_conn; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.cics_db2_conn (dla_id, data_source, scan_date) FROM stdin;
\.
COPY public.cics_db2_conn (dla_id, data_source, scan_date) FROM '$$PATH$$/3319.dat';

--
-- Data for Name: cics_file; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.cics_file (dla_id, add, browse, data_source, dataset_name, file_delete, file_group, file_name, file_read, file_update, key_length, label, open_time, record_size, scan_date, status) FROM stdin;
\.
COPY public.cics_file (dla_id, add, browse, data_source, dataset_name, file_delete, file_group, file_name, file_read, file_update, key_length, label, open_time, record_size, scan_date, status) FROM '$$PATH$$/3320.dat';

--
-- Data for Name: cics_plex; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.cics_plex (dla_id, data_source, mvs_sys_id, name, scan_date) FROM stdin;
\.
COPY public.cics_plex (dla_id, data_source, mvs_sys_id, name, scan_date) FROM '$$PATH$$/3321.dat';

--
-- Data for Name: cics_program; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.cics_program (dla_id, data_source, label, prog_data_location, prog_desc, prog_exec_key, prog_group, prog_language, prog_name, scan_date) FROM stdin;
\.
COPY public.cics_program (dla_id, data_source, label, prog_data_location, prog_desc, prog_exec_key, prog_group, prog_language, prog_name, scan_date) FROM '$$PATH$$/3322.dat';

--
-- Data for Name: cics_region; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.cics_region (dla_id, appl_id, cics_version, data_source, dfh_cics_hlq, dfh_cics_type, dfh_le_hlq, dfh_region_cicssvc, dfh_region_dfltuser, dfh_region_hlq, dfh_region_logstream, job_name, label, net_id, region_name, scan_date) FROM stdin;
\.
COPY public.cics_region (dla_id, appl_id, cics_version, data_source, dfh_cics_hlq, dfh_cics_type, dfh_le_hlq, dfh_region_cicssvc, dfh_region_dfltuser, dfh_region_hlq, dfh_region_logstream, job_name, label, net_id, region_name, scan_date) FROM '$$PATH$$/3323.dat';

--
-- Data for Name: cics_sit; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.cics_sit (dla_id, data_source, name, scan_date, sit_applid, sit_cics_svc, sit_cps_conn, sit_csd_acc, sit_csd_rls, sit_dftl_user, sit_gmtext, sit_gm_tran, sit_irc_strt, sit_isc, sit_jvm_profile_dir) FROM stdin;
\.
COPY public.cics_sit (dla_id, data_source, name, scan_date, sit_applid, sit_cics_svc, sit_cps_conn, sit_csd_acc, sit_csd_rls, sit_dftl_user, sit_gmtext, sit_gm_tran, sit_irc_strt, sit_isc, sit_jvm_profile_dir) FROM '$$PATH$$/3324.dat';

--
-- Data for Name: cics_sit_overrides; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.cics_sit_overrides (dla_id, data_source, name, scan_date, sit_applid, sit_cics_svc, sit_cps_conn, sit_csd_acc, sit_csd_rls, sit_dftl_user, sit_gmtext, sit_gm_tran, sit_irc_strt, sit_isc, sit_jvm_profile_dir) FROM stdin;
\.
COPY public.cics_sit_overrides (dla_id, data_source, name, scan_date, sit_applid, sit_cics_svc, sit_cps_conn, sit_csd_acc, sit_csd_rls, sit_dftl_user, sit_gmtext, sit_gm_tran, sit_irc_strt, sit_isc, sit_jvm_profile_dir) FROM '$$PATH$$/3325.dat';

--
-- Data for Name: cics_transaction; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.cics_transaction (dla_id, data_key, data_location, data_source, initial_program, label, scan_date, trans_name) FROM stdin;
\.
COPY public.cics_transaction (dla_id, data_key, data_location, data_source, initial_program, label, scan_date, trans_name) FROM '$$PATH$$/3326.dat';

--
-- Data for Name: db2_buffer_pool; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.db2_buffer_pool (dla_id, data_source, label, name, num_pages, page_size, pool_id, scan_date) FROM stdin;
\.
COPY public.db2_buffer_pool (dla_id, data_source, label, name, num_pages, page_size, pool_id, scan_date) FROM '$$PATH$$/3327.dat';

--
-- Data for Name: db2_data_sharing_group; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.db2_data_sharing_group (dla_id, data_source, group_attach_name, group_function, label, name, scan_date, sys_columns_max_altered_ts, sys_database_xax_altered_ts, sys_indexes_max_altered_ts, sys_table_max_altered_ts, sys_table_space_max_altered_ts) FROM stdin;
\.
COPY public.db2_data_sharing_group (dla_id, data_source, group_attach_name, group_function, label, name, scan_date, sys_columns_max_altered_ts, sys_database_xax_altered_ts, sys_indexes_max_altered_ts, sys_table_max_altered_ts, sys_table_space_max_altered_ts) FROM '$$PATH$$/3328.dat';

--
-- Data for Name: db2_database; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.db2_database (dla_id, data_source, label, name, scan_date) FROM stdin;
\.
COPY public.db2_database (dla_id, data_source, label, name, scan_date) FROM '$$PATH$$/3329.dat';

--
-- Data for Name: db2_stored_procedure; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.db2_stored_procedure (dla_id, coll_id, data_source, external_name, label, language, name, origin, routine_type, scan_date, specific_name) FROM stdin;
\.
COPY public.db2_stored_procedure (dla_id, coll_id, data_source, external_name, label, language, name, origin, routine_type, scan_date, specific_name) FROM '$$PATH$$/3330.dat';

--
-- Data for Name: db2_subsystem; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.db2_subsystem (dla_id, ddf_location, command_prefix_name, controlling_address_space, data_source, key_name, label, major_version, modifier, release, scan_date, subsystem_name) FROM stdin;
\.
COPY public.db2_subsystem (dla_id, ddf_location, command_prefix_name, controlling_address_space, data_source, key_name, label, major_version, modifier, release, scan_date, subsystem_name) FROM '$$PATH$$/3331.dat';

--
-- Data for Name: db2_table; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.db2_table (dla_id, data_base, data_source, label, name, scan_date, sharing_group, table_space) FROM stdin;
\.
COPY public.db2_table (dla_id, data_base, data_source, label, name, scan_date, sharing_group, table_space) FROM '$$PATH$$/3332.dat';

--
-- Data for Name: db2_table_space; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.db2_table_space (dla_id, comments, content_type, data_source, label, name, page_size, scan_date, size, space_id, type) FROM stdin;
\.
COPY public.db2_table_space (dla_id, comments, content_type, data_source, label, name, page_size, scan_date, size, space_id, type) FROM '$$PATH$$/3333.dat';

--
-- Data for Name: fqdn; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.fqdn (dla_id, data_source, fqdn, scan_date) FROM stdin;
\.
COPY public.fqdn (dla_id, data_source, fqdn, scan_date) FROM '$$PATH$$/3334.dat';

--
-- Data for Name: idml_operation_time; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.idml_operation_time (host_label, create_timestamp, data_source, delete_timestamp, modify_timestamp, refresh_timestamp) FROM stdin;
\.
COPY public.idml_operation_time (host_label, create_timestamp, data_source, delete_timestamp, modify_timestamp, refresh_timestamp) FROM '$$PATH$$/3335.dat';

--
-- Data for Name: ims_database; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.ims_database (dla_id, imsdatabasetype, data_source, label, name, scan_date) FROM stdin;
\.
COPY public.ims_database (dla_id, imsdatabasetype, data_source, label, name, scan_date) FROM '$$PATH$$/3336.dat';

--
-- Data for Name: ims_program; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.ims_program (dla_id, data_source, label, name, scan_date) FROM stdin;
\.
COPY public.ims_program (dla_id, data_source, label, name, scan_date) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: ims_subsystem; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.ims_subsystem (dla_id, cqsgroupname, imsplexgroupname, imssubsystype, irlmgroupname, commandprefixname, controllingaddressspace, data_source, databaseschecksum, keyname, label, programschecksum, scan_date, subsystemname, transactionschecksum, versionstring) FROM stdin;
\.
COPY public.ims_subsystem (dla_id, cqsgroupname, imsplexgroupname, imssubsystype, irlmgroupname, commandprefixname, controllingaddressspace, data_source, databaseschecksum, keyname, label, programschecksum, scan_date, subsystemname, transactionschecksum, versionstring) FROM '$$PATH$$/3338.dat';

--
-- Data for Name: ims_transaction; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.ims_transaction (dla_id, data_source, label, name, scan_date) FROM stdin;
\.
COPY public.ims_transaction (dla_id, data_source, label, name, scan_date) FROM '$$PATH$$/3339.dat';

--
-- Data for Name: ip_address; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.ip_address (dla_id, data_source, label, scan_date, string_notation) FROM stdin;
\.
COPY public.ip_address (dla_id, data_source, label, scan_date, string_notation) FROM '$$PATH$$/3340.dat';

--
-- Data for Name: ip_interface; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.ip_interface (dla_id, data_source, scan_date) FROM stdin;
\.
COPY public.ip_interface (dla_id, data_source, scan_date) FROM '$$PATH$$/3341.dat';

--
-- Data for Name: jcl_dynamic_data; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.jcl_dynamic_data (jcl_id, dataset_name, deleted, executing_sysplex_name, executing_zos_name, extra, job_name, member_name, parent_job_name, parent_lpar_name, run_on_lpar_name, sysplex_name, "timestamp", type, unique_id, version, zos_name) FROM stdin;
\.
COPY public.jcl_dynamic_data (jcl_id, dataset_name, deleted, executing_sysplex_name, executing_zos_name, extra, job_name, member_name, parent_job_name, parent_lpar_name, run_on_lpar_name, sysplex_name, "timestamp", type, unique_id, version, zos_name) FROM '$$PATH$$/3342.dat';

--
-- Data for Name: jcl_file_data; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.jcl_file_data (jcl_id, dataset_name, deleted, extra, job_descriptor_id, member_name, sysplex_name, "timestamp", type, unique_id, version) FROM stdin;
\.
COPY public.jcl_file_data (jcl_id, dataset_name, deleted, extra, job_descriptor_id, member_name, sysplex_name, "timestamp", type, unique_id, version) FROM '$$PATH$$/3343.dat';

--
-- Data for Name: jcl_operation_data; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.jcl_operation_data (jcl_id, dataset_name, deleted, executing_sysplex_name, executing_zos_name, extra, job_name, job_descriptor_id, lpar_name, member_name, parent_job_name, parent_lpar_name, route_card, sysplex_name, "timestamp", type, unique_id, version, zos_name) FROM stdin;
\.
COPY public.jcl_operation_data (jcl_id, dataset_name, deleted, executing_sysplex_name, executing_zos_name, extra, job_name, job_descriptor_id, lpar_name, member_name, parent_job_name, parent_lpar_name, route_card, sysplex_name, "timestamp", type, unique_id, version, zos_name) FROM '$$PATH$$/3344.dat';

--
-- Data for Name: jcl_route_card; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.jcl_route_card (route_card_id, deleted, extra, route_card, "timestamp", type, unique_id, version) FROM stdin;
\.
COPY public.jcl_route_card (route_card_id, deleted, extra, route_card, "timestamp", type, unique_id, version) FROM '$$PATH$$/3345.dat';

--
-- Data for Name: jcl_static_data; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.jcl_static_data (jcl_id, dataset_name, deleted, executing_sysplex_name, executing_zos_name, extra, job_name, job_descriptor_id, lpar_name, member_name, parent_job_name, parent_lpar_name, route_card, sysplex_name, "timestamp", type, unique_id, version, zos_name) FROM stdin;
\.
COPY public.jcl_static_data (jcl_id, dataset_name, deleted, executing_sysplex_name, executing_zos_name, extra, job_name, job_descriptor_id, lpar_name, member_name, parent_job_name, parent_lpar_name, route_card, sysplex_name, "timestamp", type, unique_id, version, zos_name) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: jcl_system_relationship; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.jcl_system_relationship (sysplex, deleted, lpar, "timestamp", type, version) FROM stdin;
\.
COPY public.jcl_system_relationship (sysplex, deleted, lpar, "timestamp", type, version) FROM '$$PATH$$/3347.dat';

--
-- Data for Name: lpar; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.lpar (dla_id, data_source, label, lpar_name, memory_size, model, model_id, name, num_cpus, num_dedicated_cps, num_shared_cps, scan_date, vm_id) FROM stdin;
\.
COPY public.lpar (dla_id, data_source, label, lpar_name, memory_size, model, model_id, name, num_cpus, num_dedicated_cps, num_shared_cps, scan_date, vm_id) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: module_definition; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.module_definition (dla_id, language, name, scan_date, sourcefile, type) FROM stdin;
\.
COPY public.module_definition (dla_id, language, name, scan_date, sourcefile, type) FROM '$$PATH$$/3349.dat';

--
-- Data for Name: mq_alias_queue; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.mq_alias_queue (dla_id, data_source, default_persistence, description, get, label, name, put, qsdgisp, scan_date, target_queue) FROM stdin;
\.
COPY public.mq_alias_queue (dla_id, data_source, default_persistence, description, get, label, name, put, qsdgisp, scan_date, target_queue) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: mq_auth_info; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.mq_auth_info (dla_id, data_source, label, ldap_server_name, name, queue_manager, scan_date, type, user_name) FROM stdin;
\.
COPY public.mq_auth_info (dla_id, data_source, label, ldap_server_name, name, queue_manager, scan_date, type, user_name) FROM '$$PATH$$/3351.dat';

--
-- Data for Name: mq_buffer_pool; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.mq_buffer_pool (dla_id, data_source, id_sequence, label, number, scan_date) FROM stdin;
\.
COPY public.mq_buffer_pool (dla_id, data_source, id_sequence, label, number, scan_date) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: mq_client_connection_channel; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.mq_client_connection_channel (dla_id, data_source, headercompression, heartbeatinterval, keepaliveinterval, label, maxmessagelength, messagecompression, name, queuesharinggroupdisposition, scan_date) FROM stdin;
\.
COPY public.mq_client_connection_channel (dla_id, data_source, headercompression, heartbeatinterval, keepaliveinterval, label, maxmessagelength, messagecompression, name, queuesharinggroupdisposition, scan_date) FROM '$$PATH$$/3353.dat';

--
-- Data for Name: mq_cluster_receiver_channel; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.mq_cluster_receiver_channel (dla_id, batchheartbeatinterval, batchinterval, batchsize, clwlchannelpriority, clwlchannelrank, clwlchannelweight, connectionname, dataconversion, data_source, disconnectinterval, headercompression, heartbeatinterval, keepaliveinterval, label, longretrycount, longretrytimer, maxmessagelength, mcatype, messagecompression, messageretrycount, messageretryinterval, name, nonpersistentmessagespeed, putauthority, queuesharinggroupdisposition, scan_date, shortretrycount, shortretrytimer, sslclientauthentication) FROM stdin;
\.
COPY public.mq_cluster_receiver_channel (dla_id, batchheartbeatinterval, batchinterval, batchsize, clwlchannelpriority, clwlchannelrank, clwlchannelweight, connectionname, dataconversion, data_source, disconnectinterval, headercompression, heartbeatinterval, keepaliveinterval, label, longretrycount, longretrytimer, maxmessagelength, mcatype, messagecompression, messageretrycount, messageretryinterval, name, nonpersistentmessagespeed, putauthority, queuesharinggroupdisposition, scan_date, shortretrycount, shortretrytimer, sslclientauthentication) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: mq_cluster_sender_channel; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.mq_cluster_sender_channel (dla_id, batchheartbeatinterval, batchinterval, batchsize, clwlchannelpriority, clwlchannelrank, clwlchannelweight, connectionname, dataconversion, data_source, disconnectinterval, headercompression, heartbeatinterval, keepaliveinterval, label, longretrycount, longretrytimer, maxmessagelength, messagecompression, name, nonpersistentmessagespeed, queuesharinggroupdisposition, scan_date, shortretrycount, shortretrytimer) FROM stdin;
\.
COPY public.mq_cluster_sender_channel (dla_id, batchheartbeatinterval, batchinterval, batchsize, clwlchannelpriority, clwlchannelrank, clwlchannelweight, connectionname, dataconversion, data_source, disconnectinterval, headercompression, heartbeatinterval, keepaliveinterval, label, longretrycount, longretrytimer, maxmessagelength, messagecompression, name, nonpersistentmessagespeed, queuesharinggroupdisposition, scan_date, shortretrycount, shortretrytimer) FROM '$$PATH$$/3355.dat';

--
-- Data for Name: mq_listener; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.mq_listener (dla_id, control, data_source, label, name, queuemanager, remotename, scan_date, starttime) FROM stdin;
\.
COPY public.mq_listener (dla_id, control, data_source, label, name, queuemanager, remotename, scan_date, starttime) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: mq_local_queue; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.mq_local_queue (dla_id, data_source, defaultpersistence, definitiontype, get, label, maxmessagelength, maxqueuedepth, name, put, qsgdisp, scan_date, transmissionusage, triggercontrol, triggerdata, triggerdepth, triggertype) FROM stdin;
\.
COPY public.mq_local_queue (dla_id, data_source, defaultpersistence, definitiontype, get, label, maxmessagelength, maxqueuedepth, name, put, qsgdisp, scan_date, transmissionusage, triggercontrol, triggerdata, triggerdepth, triggertype) FROM '$$PATH$$/3357.dat';

--
-- Data for Name: mq_model_queue; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.mq_model_queue (dla_id, data_source, defaultpersistence, definitiontype, description, get, initiationqueue, label, name, put, qsgdisp, scan_date, transmissionusage, triggercontrol, triggerdata, triggerdepth, triggertype) FROM stdin;
\.
COPY public.mq_model_queue (dla_id, data_source, defaultpersistence, definitiontype, description, get, initiationqueue, label, name, put, qsgdisp, scan_date, transmissionusage, triggercontrol, triggerdata, triggerdepth, triggertype) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: mq_receiver_channel; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.mq_receiver_channel (dla_id, batchsize, data_source, headercompression, heartbeatinterval, keepaliveinterval, label, maxmessagelength, messagecompression, messageretrycount, messageretryinterval, name, nonpersistentmessagespeed, putauthority, queuesharinggroupdisposition, scan_date, sslcipherspecification, sslclientauthentication) FROM stdin;
\.
COPY public.mq_receiver_channel (dla_id, batchsize, data_source, headercompression, heartbeatinterval, keepaliveinterval, label, maxmessagelength, messagecompression, messageretrycount, messageretryinterval, name, nonpersistentmessagespeed, putauthority, queuesharinggroupdisposition, scan_date, sslcipherspecification, sslclientauthentication) FROM '$$PATH$$/3359.dat';

--
-- Data for Name: mq_remote_queue; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.mq_remote_queue (dla_id, data_source, defaultpersistence, label, name, put, qsgdisp, remotename, remotequeuemgrname, scan_date) FROM stdin;
\.
COPY public.mq_remote_queue (dla_id, data_source, defaultpersistence, label, name, put, qsgdisp, remotename, remotequeuemgrname, scan_date) FROM '$$PATH$$/3360.dat';

--
-- Data for Name: mq_sender_channel; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.mq_sender_channel (dla_id, batchheartbeatinterval, batchinterval, batchsize, connectionname, dataconversion, data_source, disconnectinterval, headercompression, heartbeatinterval, keepaliveinterval, label, longretrycount, longretrytimer, maxmessagelength, messagecompression, name, nonpersistentmessagespeed, queuesharinggroupdisposition, scan_date, shortretrycount, shortretrytimer, transmissionqueue) FROM stdin;
\.
COPY public.mq_sender_channel (dla_id, batchheartbeatinterval, batchinterval, batchsize, connectionname, dataconversion, data_source, disconnectinterval, headercompression, heartbeatinterval, keepaliveinterval, label, longretrycount, longretrytimer, maxmessagelength, messagecompression, name, nonpersistentmessagespeed, queuesharinggroupdisposition, scan_date, shortretrycount, shortretrytimer, transmissionqueue) FROM '$$PATH$$/3361.dat';

--
-- Data for Name: mq_server_connection_channel; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.mq_server_connection_channel (dla_id, data_source, description, disconnectinterval, headercompression, heartbeatinterval, keepaliveinterval, label, maxmessagelength, messagecompression, name, queuesharinggroupdisposition, scan_date, sslclientauthentication) FROM stdin;
\.
COPY public.mq_server_connection_channel (dla_id, data_source, description, disconnectinterval, headercompression, heartbeatinterval, keepaliveinterval, label, maxmessagelength, messagecompression, name, queuesharinggroupdisposition, scan_date, sslclientauthentication) FROM '$$PATH$$/3362.dat';

--
-- Data for Name: mq_subsystem; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.mq_subsystem (dla_id, commandprefixname, controllingaddressspace, data_source, label, scan_date, subsystemname, versionstring) FROM stdin;
\.
COPY public.mq_subsystem (dla_id, commandprefixname, controllingaddressspace, data_source, label, scan_date, subsystemname, versionstring) FROM '$$PATH$$/3363.dat';

--
-- Data for Name: process_pool; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.process_pool (dla_id, cmd_line, data_source, label, name, scan_date) FROM stdin;
\.
COPY public.process_pool (dla_id, cmd_line, data_source, label, name, scan_date) FROM '$$PATH$$/3364.dat';

--
-- Data for Name: program_definition; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.program_definition (dla_id, language, loc, locmt, name, rloc, scan_date, type) FROM stdin;
\.
COPY public.program_definition (dla_id, language, loc, locmt, name, rloc, scan_date, type) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: relationship; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.relationship (name, source, target, data_source, reverse_name) FROM stdin;
\.
COPY public.relationship (name, source, target, data_source, reverse_name) FROM '$$PATH$$/3366.dat';

--
-- Data for Name: relationship_service_now; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.relationship_service_now (name, source, target, data_source, reverse_name, source_type, target_type) FROM stdin;
\.
COPY public.relationship_service_now (name, source, target, data_source, reverse_name, source_type, target_type) FROM '$$PATH$$/3367.dat';

--
-- Data for Name: sysplex; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.sysplex (dla_id, grs_config, data_source, label, maxsys, name, plex_mode, scan_date) FROM stdin;
\.
COPY public.sysplex (dla_id, grs_config, data_source, label, maxsys, name, plex_mode, scan_date) FROM '$$PATH$$/3368.dat';

--
-- Data for Name: table_definition; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.table_definition (dla_id, name, scan_date, type) FROM stdin;
\.
COPY public.table_definition (dla_id, name, scan_date, type) FROM '$$PATH$$/3369.dat';

--
-- Data for Name: tcp_port; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.tcp_port (dla_id, data_source, label, port_number, scan_date) FROM stdin;
\.
COPY public.tcp_port (dla_id, data_source, label, port_number, scan_date) FROM '$$PATH$$/3370.dat';

--
-- Data for Name: trancode_definition; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.trancode_definition (dla_id, name, scan_date, type) FROM stdin;
\.
COPY public.trancode_definition (dla_id, name, scan_date, type) FROM '$$PATH$$/3371.dat';

--
-- Data for Name: udp_port; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.udp_port (dla_id, data_source, label, port_number, scan_date) FROM stdin;
\.
COPY public.udp_port (dla_id, data_source, label, port_number, scan_date) FROM '$$PATH$$/3372.dat';

--
-- Data for Name: z_series_computer; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.z_series_computer (dla_id, cpu_speed, data_source, label, make, manufacturer, memory_size, model, model_id, name, num_cpus, process_capacity_units, processing_capacity, scan_date, serial_number) FROM stdin;
\.
COPY public.z_series_computer (dla_id, cpu_speed, data_source, label, make, manufacturer, memory_size, model, model_id, name, num_cpus, process_capacity_units, processing_capacity, scan_date, serial_number) FROM '$$PATH$$/3373.dat';

--
-- Data for Name: z_subsystem; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.z_subsystem (dla_id, data_source, label, scan_date, subsystem_manufacturer, subsystem_name, subsystem_version, type) FROM stdin;
\.
COPY public.z_subsystem (dla_id, data_source, label, scan_date, subsystem_manufacturer, subsystem_name, subsystem_version, type) FROM '$$PATH$$/3374.dat';

--
-- Data for Name: zos; Type: TABLE DATA; Schema: public; Owner: rgroup
--

COPY public.zos (dla_id, data_source, fqdn, ipl_parm_dataset, ipl_parm_device, ipl_parm_member, ipl_parm_volume, label, name, net_id, os_freindly_name, os_name, os_rsu_level, os_version, scan_date, smf_id, sscp, sys_res_volume) FROM stdin;
\.
COPY public.zos (dla_id, data_source, fqdn, ipl_parm_dataset, ipl_parm_device, ipl_parm_member, ipl_parm_volume, label, name, net_id, os_freindly_name, os_name, os_rsu_level, os_version, scan_date, smf_id, sscp, sys_res_volume) FROM '$$PATH$$/3375.dat';

--
-- Name: address_space address_space_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.address_space
    ADD CONSTRAINT address_space_pkey PRIMARY KEY (dla_id);


--
-- Name: bind_address bind_address_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.bind_address
    ADD CONSTRAINT bind_address_pkey PRIMARY KEY (dla_id);


--
-- Name: cics_db2_conn cics_db2_conn_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.cics_db2_conn
    ADD CONSTRAINT cics_db2_conn_pkey PRIMARY KEY (dla_id);


--
-- Name: cics_file cics_file_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.cics_file
    ADD CONSTRAINT cics_file_pkey PRIMARY KEY (dla_id);


--
-- Name: cics_plex cics_plex_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.cics_plex
    ADD CONSTRAINT cics_plex_pkey PRIMARY KEY (dla_id);


--
-- Name: cics_program cics_program_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.cics_program
    ADD CONSTRAINT cics_program_pkey PRIMARY KEY (dla_id);


--
-- Name: cics_region cics_region_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.cics_region
    ADD CONSTRAINT cics_region_pkey PRIMARY KEY (dla_id);


--
-- Name: cics_sit_overrides cics_sit_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.cics_sit_overrides
    ADD CONSTRAINT cics_sit_overrides_pkey PRIMARY KEY (dla_id);


--
-- Name: cics_sit cics_sit_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.cics_sit
    ADD CONSTRAINT cics_sit_pkey PRIMARY KEY (dla_id);


--
-- Name: cics_transaction cics_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.cics_transaction
    ADD CONSTRAINT cics_transaction_pkey PRIMARY KEY (dla_id);


--
-- Name: db2_buffer_pool db2_buffer_pool_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.db2_buffer_pool
    ADD CONSTRAINT db2_buffer_pool_pkey PRIMARY KEY (dla_id);


--
-- Name: db2_data_sharing_group db2_data_sharing_group_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.db2_data_sharing_group
    ADD CONSTRAINT db2_data_sharing_group_pkey PRIMARY KEY (dla_id);


--
-- Name: db2_database db2_database_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.db2_database
    ADD CONSTRAINT db2_database_pkey PRIMARY KEY (dla_id);


--
-- Name: db2_stored_procedure db2_stored_procedure_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.db2_stored_procedure
    ADD CONSTRAINT db2_stored_procedure_pkey PRIMARY KEY (dla_id);


--
-- Name: db2_subsystem db2_subsystem_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.db2_subsystem
    ADD CONSTRAINT db2_subsystem_pkey PRIMARY KEY (dla_id);


--
-- Name: db2_table db2_table_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.db2_table
    ADD CONSTRAINT db2_table_pkey PRIMARY KEY (dla_id);


--
-- Name: db2_table_space db2_table_space_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.db2_table_space
    ADD CONSTRAINT db2_table_space_pkey PRIMARY KEY (dla_id);


--
-- Name: fqdn fqdn_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.fqdn
    ADD CONSTRAINT fqdn_pkey PRIMARY KEY (dla_id);


--
-- Name: idml_operation_time idml_operation_time_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.idml_operation_time
    ADD CONSTRAINT idml_operation_time_pkey PRIMARY KEY (host_label);


--
-- Name: ims_database ims_database_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.ims_database
    ADD CONSTRAINT ims_database_pkey PRIMARY KEY (dla_id);


--
-- Name: ims_program ims_program_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.ims_program
    ADD CONSTRAINT ims_program_pkey PRIMARY KEY (dla_id);


--
-- Name: ims_subsystem ims_subsystem_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.ims_subsystem
    ADD CONSTRAINT ims_subsystem_pkey PRIMARY KEY (dla_id);


--
-- Name: ims_transaction ims_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.ims_transaction
    ADD CONSTRAINT ims_transaction_pkey PRIMARY KEY (dla_id);


--
-- Name: ip_address ip_address_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.ip_address
    ADD CONSTRAINT ip_address_pkey PRIMARY KEY (dla_id);


--
-- Name: ip_interface ip_interface_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.ip_interface
    ADD CONSTRAINT ip_interface_pkey PRIMARY KEY (dla_id);


--
-- Name: jcl_dynamic_data jcl_dynamic_data_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.jcl_dynamic_data
    ADD CONSTRAINT jcl_dynamic_data_pkey PRIMARY KEY (jcl_id);


--
-- Name: jcl_file_data jcl_file_data_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.jcl_file_data
    ADD CONSTRAINT jcl_file_data_pkey PRIMARY KEY (jcl_id);


--
-- Name: jcl_operation_data jcl_operation_data_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.jcl_operation_data
    ADD CONSTRAINT jcl_operation_data_pkey PRIMARY KEY (jcl_id);


--
-- Name: jcl_route_card jcl_route_card_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.jcl_route_card
    ADD CONSTRAINT jcl_route_card_pkey PRIMARY KEY (route_card_id);


--
-- Name: jcl_static_data jcl_static_data_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.jcl_static_data
    ADD CONSTRAINT jcl_static_data_pkey PRIMARY KEY (jcl_id);


--
-- Name: jcl_system_relationship jcl_system_relationship_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.jcl_system_relationship
    ADD CONSTRAINT jcl_system_relationship_pkey PRIMARY KEY (sysplex);


--
-- Name: lpar lpar_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.lpar
    ADD CONSTRAINT lpar_pkey PRIMARY KEY (dla_id);


--
-- Name: module_definition module_definition_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.module_definition
    ADD CONSTRAINT module_definition_pkey PRIMARY KEY (dla_id);


--
-- Name: mq_alias_queue mq_alias_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.mq_alias_queue
    ADD CONSTRAINT mq_alias_queue_pkey PRIMARY KEY (dla_id);


--
-- Name: mq_auth_info mq_auth_info_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.mq_auth_info
    ADD CONSTRAINT mq_auth_info_pkey PRIMARY KEY (dla_id);


--
-- Name: mq_buffer_pool mq_buffer_pool_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.mq_buffer_pool
    ADD CONSTRAINT mq_buffer_pool_pkey PRIMARY KEY (dla_id);


--
-- Name: mq_client_connection_channel mq_client_connection_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.mq_client_connection_channel
    ADD CONSTRAINT mq_client_connection_channel_pkey PRIMARY KEY (dla_id);


--
-- Name: mq_cluster_receiver_channel mq_cluster_receiver_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.mq_cluster_receiver_channel
    ADD CONSTRAINT mq_cluster_receiver_channel_pkey PRIMARY KEY (dla_id);


--
-- Name: mq_cluster_sender_channel mq_cluster_sender_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.mq_cluster_sender_channel
    ADD CONSTRAINT mq_cluster_sender_channel_pkey PRIMARY KEY (dla_id);


--
-- Name: mq_listener mq_listener_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.mq_listener
    ADD CONSTRAINT mq_listener_pkey PRIMARY KEY (dla_id);


--
-- Name: mq_local_queue mq_local_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.mq_local_queue
    ADD CONSTRAINT mq_local_queue_pkey PRIMARY KEY (dla_id);


--
-- Name: mq_model_queue mq_model_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.mq_model_queue
    ADD CONSTRAINT mq_model_queue_pkey PRIMARY KEY (dla_id);


--
-- Name: mq_receiver_channel mq_receiver_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.mq_receiver_channel
    ADD CONSTRAINT mq_receiver_channel_pkey PRIMARY KEY (dla_id);


--
-- Name: mq_remote_queue mq_remote_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.mq_remote_queue
    ADD CONSTRAINT mq_remote_queue_pkey PRIMARY KEY (dla_id);


--
-- Name: mq_sender_channel mq_sender_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.mq_sender_channel
    ADD CONSTRAINT mq_sender_channel_pkey PRIMARY KEY (dla_id);


--
-- Name: mq_server_connection_channel mq_server_connection_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.mq_server_connection_channel
    ADD CONSTRAINT mq_server_connection_channel_pkey PRIMARY KEY (dla_id);


--
-- Name: mq_subsystem mq_subsystem_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.mq_subsystem
    ADD CONSTRAINT mq_subsystem_pkey PRIMARY KEY (dla_id);


--
-- Name: process_pool process_pool_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.process_pool
    ADD CONSTRAINT process_pool_pkey PRIMARY KEY (dla_id);


--
-- Name: program_definition program_definition_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.program_definition
    ADD CONSTRAINT program_definition_pkey PRIMARY KEY (dla_id);


--
-- Name: relationship relationship_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.relationship
    ADD CONSTRAINT relationship_pkey PRIMARY KEY (name, source, target);


--
-- Name: relationship_service_now relationship_service_now_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.relationship_service_now
    ADD CONSTRAINT relationship_service_now_pkey PRIMARY KEY (name, source, target);


--
-- Name: sysplex sysplex_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.sysplex
    ADD CONSTRAINT sysplex_pkey PRIMARY KEY (dla_id);


--
-- Name: table_definition table_definition_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.table_definition
    ADD CONSTRAINT table_definition_pkey PRIMARY KEY (dla_id);


--
-- Name: tcp_port tcp_port_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.tcp_port
    ADD CONSTRAINT tcp_port_pkey PRIMARY KEY (dla_id);


--
-- Name: trancode_definition trancode_definition_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.trancode_definition
    ADD CONSTRAINT trancode_definition_pkey PRIMARY KEY (dla_id);


--
-- Name: udp_port udp_port_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.udp_port
    ADD CONSTRAINT udp_port_pkey PRIMARY KEY (dla_id);


--
-- Name: cics_region uk_j1xy8np9mh2peo6m1pxsy906w; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.cics_region
    ADD CONSTRAINT uk_j1xy8np9mh2peo6m1pxsy906w UNIQUE (region_name);


--
-- Name: z_series_computer z_series_computer_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.z_series_computer
    ADD CONSTRAINT z_series_computer_pkey PRIMARY KEY (dla_id);


--
-- Name: z_subsystem z_subsystem_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.z_subsystem
    ADD CONSTRAINT z_subsystem_pkey PRIMARY KEY (dla_id);


--
-- Name: zos zos_pkey; Type: CONSTRAINT; Schema: public; Owner: rgroup
--

ALTER TABLE ONLY public.zos
    ADD CONSTRAINT zos_pkey PRIMARY KEY (dla_id);


--
-- Name: dbz_publication; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION dbz_publication FOR ALL TABLES WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION dbz_publication OWNER TO postgres;

--
-- PostgreSQL database dump complete
--

